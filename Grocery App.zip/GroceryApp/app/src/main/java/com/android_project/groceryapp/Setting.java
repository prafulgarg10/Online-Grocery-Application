package com.android_project.groceryapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android_project.groceryapp.register.DatabaseHelper;

public class Setting extends AppCompatActivity {

    private ImageView back;
    private TextView user, email, password;
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);
        back = findViewById(R.id.backbtn);
        user = findViewById(R.id.user);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

            try {
                Intent i = getIntent();
                String user_email = i.getStringExtra("email");
                if(user_email==null){
                    user.setText("Paramartha");
                    email.setText("barik@gmail.com");
                    password.setText("12345");

                }
                else {
                    db = new DatabaseHelper(Setting.this);
                    String user_detail = db.getUser(user_email);
                    String arr[] = user_detail.split(" ");

                    user.setText(arr[1].toString());
                    email.setText(arr[2].toString());
                    password.setText(arr[3].toString());
                }

            } catch (Exception e) {
                System.out.println(e);
            }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Setting.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
