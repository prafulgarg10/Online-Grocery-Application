package com.android_project.groceryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android_project.groceryapp.Database.DatabaseHelper;

public class ProductDetails extends AppCompatActivity {
    ImageView imageViewProduct, imageViewBack,btnCart;
    TextView txtName, txtDesc, txtPrice;
    Button btn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        Intent i =getIntent();
        String name = i.getStringExtra("name");
        String desc = i.getStringExtra("desc");
        String price = i.getStringExtra("price");
        int image = i.getIntExtra("image",R.drawable.b1);
        txtName = findViewById(R.id.lblPName);
        txtDesc = findViewById(R.id.lblPDesc);
        txtPrice = findViewById(R.id.lblPPrice);
        btn = findViewById(R.id.btnBuyNow);
        imageViewProduct= findViewById(R.id.imgProduct);
        imageViewBack = findViewById(R.id.imgBack);
        btnCart = findViewById(R.id.btnCart);
        txtName.setText(name);
        txtPrice.setText(price);
        txtDesc.setText(desc);
        imageViewProduct.setImageResource(image);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(ProductDetails.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String arr[] = price.split(" ");
                db = new DatabaseHelper(ProductDetails.this);
                db.addOne(new Item(1,name,Integer.parseInt(arr[1])));
                Toast.makeText(ProductDetails.this, "Item added to Cart", Toast.LENGTH_SHORT).show();
            }
        });
        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ProductDetails.this,Cart.class);
                startActivity(intent);
                finish();
            }
        });
    }
}