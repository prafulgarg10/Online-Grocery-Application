package com.android_project.groceryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android_project.groceryapp.Database.DatabaseHelper;

public class Cart extends AppCompatActivity {
    private DatabaseHelper db;
    private ArrayAdapter itemAdap;
    private ListView lstv;
    private  Item item;
    private ImageView back;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);
        lstv = findViewById(R.id.itemList);
        back = findViewById(R.id.backbtn);
        db = new DatabaseHelper(Cart.this);
        ItemList();
        lstv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String) parent.getItemAtPosition(position);
                String arr[] = item.split("\n");
                String arr1[] = arr[0].split(": ");
                try {
                    db.deleteString(Integer.parseInt(arr1[1]));
                    Toast.makeText(Cart.this, "Item deleted" ,Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    System.out.println(e);
                }
                ItemList();

            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Cart.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void ItemList() {
        itemAdap = new ArrayAdapter<>(Cart.this, R.layout.cartresult, db.getAll());
        lstv.setAdapter(itemAdap);
    }
}
