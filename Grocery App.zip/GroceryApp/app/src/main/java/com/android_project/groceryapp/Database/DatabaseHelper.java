package com.android_project.groceryapp.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.android_project.groceryapp.Item;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String ITEM_TABLE = "ITEM_TABLE";
    public static final String ITEM_ID = "ID";
    public static final String ITEM_NAME = "NAME";
    public static final String ITEM_PRICE = "PRICE";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "item.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + ITEM_TABLE + " (" + ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + ITEM_NAME + " TEXT, " + ITEM_PRICE + " INT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean addOne(Item item){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues(); //Gives associative array kind of
        cv.put(ITEM_NAME, item.getName());
        cv.put(ITEM_PRICE, item.getPrice());
        long insert = db.insert(ITEM_TABLE, null, cv);
        if (insert == -1) {
            return false;
        }
        return true;
    }
    public boolean deleteOne(Item item){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + ITEM_TABLE + " WHERE " + ITEM_ID + " = " + item.getId();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }
    public boolean deleteString(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + ITEM_TABLE + " WHERE " + ITEM_ID + " = " + id ;
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()){
            return true;
        }
        else {
            return false;
        }
    }
    public List<String> getAll(){
        List<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + ITEM_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery(queryString, null);
        if(result.moveToFirst()){
            do {
                int id = result.getInt(0);
                String name = result.getString(1);
                int price = result.getInt(2);
                Item item = new Item(id, name, price);
                returnList.add("Id: " + id + "\nItem Name: " + item.getName() + "\nItem Price: " + item.getPrice() + "\nQuantity: 1");


            }while (result.moveToNext());
        }else{

        }
        result.close();
        db.close();
        return returnList;
    }
}
